package capstone.bookeshopping.service;

import capstone.bookeshopping.model.BookDetails;
import capstone.bookeshopping.repository.BookDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;


import java.util.ArrayList;
import java.util.List;

@Service
public class BookService {

    @Autowired
    BookDetailsRepository bookDetailsRepository;

//    public List<BookDetails> getAllBooks(String title) {
//        List<BookDetails> bookDetailsList = new ArrayList<BookDetails>();
//        if (title == null)
//            bookDetailsList.addAll(bookDetailsRepository.findAll());
//        else
//            bookDetailsList.addAll(bookDetailsRepository.findByTitleIgnoreCase(title));
//        if (bookDetailsList.isEmpty()) {
//            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//        }
//        return new ResponseEntity<>(bookDetailsList, HttpStatus.OK);
//    }

    public ResponseEntity<BookDetails> getBookDetailsById(@PathVariable("id") Long id) {
        BookDetails tutorial = bookDetailsRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Book with id = " + id));
        return new ResponseEntity<>(tutorial, HttpStatus.OK);
    }

    public ResponseEntity<BookDetails> createBookDetails(@RequestBody BookDetails book) {
        BookDetails bookDetails = bookDetailsRepository.save(
                new BookDetails(
                        book.getId(),book.getTitle(), book.getDescription() ,
                        book.getAuthor(), book.getCoAuthor(),
                        book.getQtyForSale(),book.getSellingPrice(),book.getSellingDiscount(),
                        book.getQtyForRent(),book.getRentingPrice(),book.getRentingDiscount(),
                        book.isHasElectBookVersion(), book.getElectBookPrice(), book.getElectBookDiscount(),
                        book.getBookCategories()
                        ));
        return new ResponseEntity<>(bookDetails, HttpStatus.CREATED);
    }

    public ResponseEntity<BookDetails> updateBookDetails(@PathVariable("id") Long id, @RequestBody BookDetails book) {
        BookDetails bookDetails = bookDetailsRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Not found Tutorial with id = " + id));
        bookDetails.setTitle(book.getTitle());
        bookDetails.setDescription(book.getDescription());
        bookDetails.setAuthor(book.getAuthor());
        bookDetails.setCoAuthor(book.getCoAuthor());
        bookDetails.setQtyForSale(book.getQtyForSale());
        bookDetails.setSellingPrice(book.getSellingPrice());
        bookDetails.setSellingDiscount(book.getSellingDiscount());
        bookDetails.setQtyForRent(book.getQtyForRent());
        bookDetails.setRentingPrice(book.getRentingPrice());
        bookDetails.setRentingDiscount(book.getRentingDiscount());
        bookDetails.setHasElectBookVersion(book.isHasElectBookVersion());
        bookDetails.setElectBookPrice(book.getElectBookPrice());
        bookDetails.setElectBookDiscount(book.getElectBookDiscount());
        return new ResponseEntity<>(bookDetailsRepository.save(bookDetails), HttpStatus.OK);
    }

    public ResponseEntity<HttpStatus> deleteBookDetails(@PathVariable("id") Long id) {
        bookDetailsRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    public ResponseEntity<HttpStatus> deleteAllBookDetails() {
        bookDetailsRepository.deleteAll();
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    public ResponseEntity<List<BookDetails>> findHasEbook() {
        List<BookDetails> eBook = bookDetailsRepository.findBookDetailsByHasElectBookVersion(true);
        if (eBook.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(eBook, HttpStatus.OK);
    }

    public List<BookDetails> getAllBooks() {
        return bookDetailsRepository.findAll();
    }
}
