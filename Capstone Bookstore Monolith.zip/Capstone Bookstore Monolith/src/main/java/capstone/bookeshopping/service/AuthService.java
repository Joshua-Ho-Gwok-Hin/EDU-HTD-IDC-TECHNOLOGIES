package capstone.bookeshopping.service;

import capstone.bookeshopping.dto.AuthRequest;
import capstone.bookeshopping.dto.AuthResponse;
import capstone.bookeshopping.dto.AuthResponseEmail;
import capstone.bookeshopping.model.User;
import capstone.bookeshopping.repository.AuthRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;

@Service
public class AuthService {

    @Autowired
    private AuthRepository authRepository;

    public void register(AuthRequest authRequest) {
        User user = new User();
        user.setFname(authRequest.getFname());
        user.setLname(authRequest.getLname());
        user.setEmail(authRequest.getEmail());
        user.setPhone(authRequest.getPhone());
        user.setDob(authRequest.getDate());
        user.setGender(authRequest.getGender());
        user.setPassword(authRequest.getPassword());
        authRepository.save(user);
    }

    public AuthResponse loginId(AuthRequest authRequest) {
        User user = authRepository.findById(authRequest.getId()).get();
        return new AuthResponse(user.getId(), user.getFname(), user.getLname(), user.getEmail(), user.getPhone(), (Date) user.getDob(), user.getGender(), user.isAdmin());
    }
    public AuthResponseEmail loginByEmail(AuthRequest authRequest) {
        User user = authRepository.findByEmail(authRequest.getEmail()).get();
        return new AuthResponseEmail(user.getId(), user.getFname(), user.getLname(), user.getEmail(), user.getPhone(), (Date) user.getDob(), user.getGender(), user.isAdmin());
    }

}
