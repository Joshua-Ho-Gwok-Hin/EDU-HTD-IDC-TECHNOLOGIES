package capstone.bookeshopping.service;

import capstone.bookeshopping.model.BookCategory;
import capstone.bookeshopping.model.BookDetails;
import capstone.bookeshopping.repository.BookCategoryRepository;
import capstone.bookeshopping.repository.BookDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BookCategoryService {

    @Autowired
    private BookCategoryRepository categoryRepository;
    @Autowired
    private BookDetailsRepository bookDetailsRepository;

    public ResponseEntity<List<BookCategory>> getAllCategory() {
        List<BookCategory> categories = new ArrayList<BookCategory>();
        categoryRepository.findAll().forEach(categories::add);
        if (categories.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(categories, HttpStatus.OK);
    }

    public ResponseEntity<List<BookCategory>> getAllBookCategoriesByBookDetailsId(Long id) {
        if (!bookDetailsRepository.existsById(id)) {
            throw new ResourceNotFoundException("Not found Tutorial with id = " + id);
        }
        List<BookCategory> categories = categoryRepository.findBookCategoriesByBookDetailsListId(id);
        return new ResponseEntity<>(categories, HttpStatus.OK);
    }

    public ResponseEntity<BookCategory> getBookCategoriesById(Long id) {
        BookCategory category = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Not found Tag with id = " + id));
        return new ResponseEntity<>(category, HttpStatus.OK);
    }

    public ResponseEntity<List<BookDetails>> getAllBookDetailsListByBookCategoryId(Long categoryId) {
        if (!categoryRepository.existsById(categoryId)) {
            throw new ResourceNotFoundException("Not found Tag  with id = " + categoryId);
        }
        List<BookDetails> bookDetailsList = bookDetailsRepository.findBookDetailsListByBookCategoriesId(categoryId);
        return new ResponseEntity<>(bookDetailsList, HttpStatus.OK);
    }

    public ResponseEntity<BookCategory> addCategory(Long bookId, BookCategory categoryRequest) {
        BookCategory category = bookDetailsRepository.findById(bookId).map(book -> {
            long categoryId = categoryRequest.getId();
            if (categoryId != 0L) {
                BookCategory _category = categoryRepository.findById(categoryId)
                        .orElseThrow(() -> new ResourceNotFoundException("Not found Tag with id = " + categoryId));
                book.addCategory(_category);
                bookDetailsRepository.save(book);
                return _category;
            }
            book.addCategory(categoryRequest);
            return categoryRepository.save(categoryRequest);
        }).orElseThrow(() -> new ResourceNotFoundException("Not found Tutorial with id = " + bookId));
        return new ResponseEntity<>(category, HttpStatus.CREATED);
    }

    public ResponseEntity<BookCategory> updateCategory(Long id, BookCategory bookRequest) {
        BookCategory tag = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("TagId " + id + "not found"));
        tag.setName(bookRequest.getName());
        return new ResponseEntity<>(categoryRepository.save(tag), HttpStatus.OK);
    }


    public ResponseEntity<HttpStatus> deleteCategoryFromBook(Long bookId, Long categoryId) {
        BookDetails bookDetails = bookDetailsRepository.findById(bookId)
                .orElseThrow(() -> new ResourceNotFoundException("Not found Tutorial with id = " + bookId));
        bookDetails.removeCategory(categoryId);
        bookDetailsRepository.save(bookDetails);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    public ResponseEntity<HttpStatus> deleteCategory(Long id) {
        categoryRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
