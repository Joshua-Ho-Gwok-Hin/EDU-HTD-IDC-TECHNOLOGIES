package capstone.bookeshopping.repository;

import capstone.bookeshopping.model.BookCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface BookCategoryRepository extends JpaRepository<BookCategory, Long> {
    List<BookCategory> findBookCategoriesByBookDetailsListId(Long id);
}