package capstone.bookeshopping.repository;

import capstone.bookeshopping.model.BookDetails;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookDetailsRepository extends JpaRepository<BookDetails, Long> {
    List<BookDetails> findByTitleIgnoreCase(String title);
    List<BookDetails> findBookDetailsByBookCategoriesId(Long id);
    List<BookDetails> findBookDetailsByHasElectBookVersion(boolean hasElectBook);
    List<BookDetails> findBookDetailsListByBookCategoriesId(Long categoryId);
}