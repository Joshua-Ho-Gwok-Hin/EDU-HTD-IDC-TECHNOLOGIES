package capstone.bookeshopping.model;

import lombok.*;

import javax.persistence.*;
import java.sql.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@TableGenerator(name = "initial", initialValue=100000)
@Table(name = "user", uniqueConstraints = {
        @UniqueConstraint(name = "uc_user_email", columnNames = {"email"})
})
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "initial")
    private Long id;

    private String fname;
    private String lname;
    private String phone;
    private String gender;
    private boolean isAdmin;

//    private String dob;
//    @Temporal(TemporalType.DATE)
//    private java.util.Date dob;
    private Date dob;

    private String email;
    private String password;

}