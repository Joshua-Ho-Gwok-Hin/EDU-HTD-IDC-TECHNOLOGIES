package capstone.bookeshopping.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.ToString;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "bk_category_entity")
public class BookCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @ManyToMany(fetch = FetchType.LAZY,
            cascade = {
                    CascadeType.PERSIST,
                    CascadeType.MERGE
            },
            mappedBy = "bookCategories")
    @JsonIgnore
    @ToString.Exclude
    private Set<BookDetails> bookDetailsList = new HashSet<>();

    public BookCategory() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<BookDetails> getBookDetailsList() {
        return bookDetailsList;
    }

    public void setBookDetailsList(Set<BookDetails> bookDetailsList) {
        this.bookDetailsList = bookDetailsList;
    }


}