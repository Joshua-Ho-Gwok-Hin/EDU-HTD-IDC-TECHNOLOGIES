package capstone.bookeshopping.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "book_details")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class BookDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "book_id", nullable = false)
    private Long id;

    private String title;
    private String description;
    private String author;
    private String coAuthor;

    private int qtyForSale;
    private double sellingPrice;
    private double sellingDiscount;

    private int qtyForRent;
    private double rentingPrice;
    private double rentingDiscount;

    @Column(name = "has_ebook_version")
    private boolean hasElectBookVersion;
    @Column(name = "ebook_price")
    private double electBookPrice;
    @Column(name = "ebook_discount")
    private double electBookDiscount;

    //    ************************************************************

    @ManyToMany(fetch = FetchType.LAZY,
            cascade = {
                    CascadeType.MERGE, CascadeType.PERSIST})
    @JoinTable(
            name = "book_category",
            joinColumns = {@JoinColumn(name = "book_id")},
            inverseJoinColumns = {@JoinColumn(name = "category_id")})
    private Set<BookCategory> bookCategories = new HashSet<>();

    public void addCategory(BookCategory category) {
        this.bookCategories.add(category);
        category.getBookDetailsList().add(this);
    }

    public void removeCategory(long id) {
        BookCategory category = this.bookCategories
                .stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(null);
        if (category != null) {
            this.bookCategories.remove(category);
            category.getBookDetailsList().remove(this);
        }
    }
}