package capstone.bookeshopping.controller;

import capstone.bookeshopping.model.BookCategory;
import capstone.bookeshopping.model.BookDetails;
import capstone.bookeshopping.service.BookCategoryService;
import capstone.bookeshopping.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:8080")
@RestController
@RequestMapping("/api")
public class BookCategoryController {

    @Autowired
    private BookService bookDetailsRepository;
    @Autowired
    private BookCategoryService categoryService;

    @GetMapping("/categories")
    public ResponseEntity<List<BookCategory>> getAllCategory() {
        return categoryService.getAllCategory();
    }

    @GetMapping("/books/{bookId}/categories")
    public ResponseEntity<List<BookCategory>> getAllBookCategoriesByBookDetailsId(@PathVariable(value = "bookId") Long id) {
        return categoryService.getAllBookCategoriesByBookDetailsId(id);
    }

    @GetMapping("/categories/{id}")
    public ResponseEntity<BookCategory> getBookCategoriesById(@PathVariable(value = "id") Long id) {
        return categoryService.getBookCategoriesById(id);
    }

    @GetMapping("/categories/{categoryId}/books")
    public ResponseEntity<List<BookDetails>> getAllBookDetailsListByBookCategoryId(@PathVariable(value = "categoryId") Long categoryId) {
        return categoryService.getAllBookDetailsListByBookCategoryId(categoryId);
    }

    @PostMapping("/books/{bookId}/categories")
    public ResponseEntity<BookCategory> addCategory(@PathVariable(value = "bookId") Long bookId, @RequestBody BookCategory categoryRequest) {
        return categoryService.addCategory(bookId, categoryRequest);
    }

    @PutMapping("/categories/{id}")
    public ResponseEntity<BookCategory> updateCategory(@PathVariable("id") Long id, @RequestBody BookCategory bookRequest) {
        return categoryService.updateCategory(id, bookRequest);
    }

    @DeleteMapping("/books/{bookId}/categories/{categoryId}")
    public ResponseEntity<HttpStatus> deleteCategoryFromBook(@PathVariable(value = "bookId") Long bookId, @PathVariable(value = "categoryId") Long categoryId) {
        return categoryService.deleteCategoryFromBook(bookId, categoryId);
    }

    @DeleteMapping("/categories/{id}")
    public ResponseEntity<HttpStatus> deleteCategory(@PathVariable("id") Long id) {
        return categoryService.deleteCategory(id);
    }











}
