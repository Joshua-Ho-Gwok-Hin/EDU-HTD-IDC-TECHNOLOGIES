package capstone.bookeshopping.controller;

import capstone.bookeshopping.model.BookDetails;
import capstone.bookeshopping.repository.BookDetailsRepository;
import capstone.bookeshopping.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin("http://localhost:8080/")
@RestController
@RequestMapping("/api")
public class BookController {

    @Autowired
    private BookService bookService;

    @Autowired
    private BookDetailsRepository bookDetailsRepository;

    @GetMapping("books/all")
    public ResponseEntity<List<BookDetails>> getAll() {
        return new ResponseEntity<>(bookService.getAllBooks(), HttpStatus.OK);
    }

    @GetMapping("/books/{id}")
    public ResponseEntity<BookDetails> getBookDetailsById(@PathVariable("id") Long id) {
        return bookService.getBookDetailsById(id);
    }

    @PostMapping("/books")
    public ResponseEntity<BookDetails> createBookDetails(@RequestBody BookDetails bookDetails) {
        return bookService.createBookDetails(bookDetails);
    }

    @PutMapping("/books/{id}")
    public ResponseEntity<BookDetails> updateBookDetails(@PathVariable("id") Long id, @RequestBody BookDetails bookDetails) {
        return bookService.updateBookDetails(id, bookDetails);
    }

    @DeleteMapping("/books/{id}")
    public ResponseEntity<HttpStatus> deleteBookDetails(@PathVariable("id") Long id) {
        return bookService.deleteBookDetails(id);
    }

    @DeleteMapping("/books")
    public ResponseEntity<HttpStatus> deleteAllBookDetails() {
        return bookService.deleteAllBookDetails();
    }

    @GetMapping("/books/ebook")
    public ResponseEntity<List<BookDetails>> findHasEbook() {
        return bookService.findHasEbook();
    }

}
