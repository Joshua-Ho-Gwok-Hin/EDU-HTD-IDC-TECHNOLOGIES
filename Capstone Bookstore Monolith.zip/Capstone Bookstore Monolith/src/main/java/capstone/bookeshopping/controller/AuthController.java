package capstone.bookeshopping.controller;

import capstone.bookeshopping.dto.AuthRequest;
import capstone.bookeshopping.dto.AuthResponse;
import capstone.bookeshopping.dto.AuthResponseEmail;
import capstone.bookeshopping.dto.AuthResponseIsAdmin;
import capstone.bookeshopping.model.User;
import capstone.bookeshopping.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("http://localhost:4200/")
@RequestMapping("/api/auth")
@RestController
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@RequestBody AuthRequest authRequest) {
        authService.register(authRequest);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("/register-admin")
    public ResponseEntity<AuthResponseIsAdmin> registerAsAdmin(@RequestBody AuthRequest authRequest) {
        authService.register(authRequest);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("/login-id")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest authRequest) {
        AuthResponse authResponse = authService.loginId(authRequest);
        return new ResponseEntity<>(authResponse, HttpStatus.OK);
    }

    @PostMapping("/login-email")
    public ResponseEntity<AuthResponseEmail> loginByEmail(@RequestBody AuthRequest authRequest) {
        AuthResponseEmail authResponseEmail = authService.loginByEmail(authRequest);
        return new ResponseEntity<>(authResponseEmail, HttpStatus.OK);
    }

}
