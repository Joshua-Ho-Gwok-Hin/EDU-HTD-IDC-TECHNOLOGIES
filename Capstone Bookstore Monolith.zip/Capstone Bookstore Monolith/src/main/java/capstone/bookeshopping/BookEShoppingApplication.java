package capstone.bookeshopping;

import capstone.bookeshopping.model.BookCategory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookEShoppingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookEShoppingApplication.class, args);

		BookCategory horror = new BookCategory();

	}
}
