package capstone.bookeshopping.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuthResponseEmail {
    private Long id;
    private String fname;
    private String lname;
    private String email;
    private String phone;
    private Date dob;
    private String gender;
    private boolean isAdmin=false;
}
