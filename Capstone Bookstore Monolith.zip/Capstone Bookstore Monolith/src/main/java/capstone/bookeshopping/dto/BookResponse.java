package capstone.bookeshopping.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookResponse {

    private Long id;
    private String title;
    private String description;
    private String author;
    private String coAuthor;

    private int qtyForSale;
    private double sellingPrice;
    private double sellingDiscount;

    private int qtyForRent;
    private double rentingPrice;
    private double rentingDiscount;

    private boolean hasEBookVersion;
    private double eBookPrice;
    private double eBookDiscount;

}
