package capstone.bookeshopping.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.sql.Date;
//import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuthRequest {

    private Long id;
    private String fname;
    private String lname;
    private String email;
    private String phone;
    private String gender;
//    private String date;
    private Date date; // need to check
    private String password;

}
