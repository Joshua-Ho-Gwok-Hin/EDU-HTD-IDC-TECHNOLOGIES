package capstone.bookeshopping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookEShoppingApplicationTests {

	@Test
	void contextLoads() {
	}

}
