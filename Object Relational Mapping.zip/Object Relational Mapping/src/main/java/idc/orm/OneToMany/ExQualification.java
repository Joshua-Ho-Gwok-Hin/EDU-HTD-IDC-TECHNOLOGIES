package idc.orm.OneToMany;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "ExQualification")
@Table(name = "ex_qualification")
public class ExQualification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "ex_employee_id")
    private ExEmployee exEmployee;

    public ExEmployee getExEmployee() {
        return exEmployee;
    }

    public void setExEmployee(ExEmployee exEmployee) {
        this.exEmployee = exEmployee;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

}