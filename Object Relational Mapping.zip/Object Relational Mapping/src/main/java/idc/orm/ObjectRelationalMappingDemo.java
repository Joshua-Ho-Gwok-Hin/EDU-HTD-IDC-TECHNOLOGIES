package idc.orm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObjectRelationalMappingDemo {

	public static void main(String[] args) {
		SpringApplication.run(ObjectRelationalMappingDemo.class, args);
	}
}
