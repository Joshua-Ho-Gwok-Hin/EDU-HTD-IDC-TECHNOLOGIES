package idc.orm.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "ExLogin")
@Table(name = "ex_login")
public class ExLogin {
    @Id
    @Column(name = "user_id", nullable = false)
    private Long id;

    @OneToOne
    @MapsId
    @JoinColumn(name = "user_id")
    private ExUserProfile exUserProfile;

    @Column(name = "user_name")
    private String username;

    @Column(name = "pass_word")
    private String password;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


}