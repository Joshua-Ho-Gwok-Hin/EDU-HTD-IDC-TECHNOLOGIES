

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/EnterName")
public class EnterName extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		pleaseAdd(request, response);
	}
	
	protected void pleaseAdd(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		String firstName = request.getParameter("fname");
		String lastName = request.getParameter("lname");
		
		PrintWriter output = response.getWriter();
		response.setContentType("text/html");
		
		output.println("Your full name is " + firstName + " " + lastName);
		
		RequestDispatcher includeToPage = request.getRequestDispatcher("index.jsp");
		includeToPage.include(request, response);
		
	
	}

}
