
public class ClassDetails {
	
	private String classname;
	private int grade;
	
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	
	public ClassDetails(String classname, int grade) {
		super();
		this.classname = classname;
		this.grade = grade;
	}
	
}
