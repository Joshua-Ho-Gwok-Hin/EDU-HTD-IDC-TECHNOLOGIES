package com.corejava.assignment.week1.userlogin;

public interface Authenticate {

    boolean isLoginSuccessful(String username, String password);

}
