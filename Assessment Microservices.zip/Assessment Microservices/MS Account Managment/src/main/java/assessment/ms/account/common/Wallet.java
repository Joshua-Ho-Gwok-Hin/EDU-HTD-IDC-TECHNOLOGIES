package assessment.ms.account.common;

public class Wallet {

    private int id;

    private String tId;
    private String status;

    private double amount;
    private int accountId;
}
